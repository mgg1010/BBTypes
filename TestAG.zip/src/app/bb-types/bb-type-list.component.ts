import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BBTypeService } from '../services/bb-type.service';
import { BBType, BBSettingDefinition } from '../models/bb-types';
import { BBTypeBuilderComponent } from './bb-type-builder.component';
import { DynamicFieldComponent } from '../shared/dynamic-field.component';
import { AppConfig } from '../models/app-models';
import { map } from 'rxjs/operators';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { EditorMode, EditorSize } from '../shared/editor.interface';

@Component({
  selector: 'app-bb-type-list',
  standalone: true,
  imports: [CommonModule, FormsModule, BBTypeBuilderComponent, DynamicFieldComponent],
  template: `
    <div class="type-manager">
      @if (view === 'list') {
        <div class="toolbar">
            <button class="primary-btn" (click)="view = 'create'">+ New Type</button>
            <label class="filter-check">
                <input type="checkbox" [(ngModel)]="hideSystemTypes" (ngModelChange)="onFilterChange()">
                Hide system types
            </label>
            <div class="spacer"></div>
            <button class="action-btn danger-btn" (click)="resetAll()" style="color: #d32f2f; border-color: #d32f2f;">⚠️ Reset All</button>
            <button class="action-btn" (click)="downloadConfig()">💾 Save (Download)</button>
            <button class="action-btn" (click)="fileInput.click()">📂 Load (Upload)</button>
            <input #fileInput type="file" (change)="loadConfig($event)" style="display: none" accept=".json">
        </div>

        <table class="type-table">
            <thead>
            <tr>
                <th>Name</th>
                <th>Base Type</th>
                <th>Source</th>
                <th>Details</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            @for (type of types$ | async; track type.id) {
                <tr>
                <td><strong>{{ type.name }}</strong></td>
                <td><span class="badge {{type.baseType}}">{{ type.baseType }}</span></td>
                <td>
                    @if (appConfig) {
                        @if (type.userDefined) {
                            <span class="tag user">App</span>
                        } @else {
                            <span class="tag system">System</span>
                        }
                    } @else {
                        @if (type.userDefined) {
                            <span class="tag user">User</span>
                        } @else {
                            <span class="tag system">System</span>
                        }
                    }
                </td>
                <td>
                    @if (type.baseType === 'List' || type.baseType === 'Dict') {
                        {{ type.baseType }} of {{ getTypeName(type.subtypeId) }}
                    } @else if (type.baseType === 'Basic') {
                         Based on {{ getTypeName(type.subtypeId) }} ({{ type.values?.length || 0 }} values)
                    } @else if (type.fields) {
                        {{ type.fields.length }} Fields
                    }
                </td>
                <td>
                    @if (type.userDefined) {
                        <button class="edit-btn" (click)="editType(type)">✏️ Edit</button>
                        <button 
                            class="delete-btn" 
                            [class.disabled]="isTypeRef(type.id)" 
                            [title]="isTypeRef(type.id) ? 'Cannot delete: Type is used by ' + getRefNames(type.id) : 'Delete Type'"
                            (click)="!isTypeRef(type.id) && deleteType(type)">
                            🗑️
                        </button>
                    }
                    <button class="test-btn" (click)="openTestEditor(type)">🧪 Test</button>
                </td>
                </tr>
            }
            </tbody>
        </table>
      } @else {
          <app-bb-type-builder 
            [editingType]="editingType"
            [appConfig]="appConfig"
            (cancel)="cancelEdit()"
            (create)="onTypeCreated($event)">
          </app-bb-type-builder>
      }
      
      <!-- Test Editor Modal -->
      @if (testingType) {
        <div class="modal-overlay" (click)="closeTestEditor()">
          <div class="test-modal-content resizable-modal" [class.with-sidebar]="showTestSidebar" (click)="$event.stopPropagation()">
            <div class="resize-handle"></div>
            <div class="test-modal-main">
                <div class="modal-header">
                  <h3>Test Editor: {{ testingType.name }}</h3>
                  <div class="header-actions">
                      <button class="sidebar-toggle" [class.active]="showTestSidebar" (click)="showTestSidebar = !showTestSidebar">
                          {{ showTestSidebar ? 'Hide Settings ⇥' : 'Customize 🔧' }}
                      </button>
                      <button class="close-btn" (click)="closeTestEditor()">✕</button>
                  </div>
                </div>
                <div class="test-preview-area">
                    <div class="test-field-container">
                        <app-dynamic-field
                            [typeId]="testingType.id"
                            [appConfig]="appConfig"
                            [(value)]="testValue"
                            [mode]="testSettings['UI.EditMode'] === 'read' ? 'read' : 'edit'"
                            [size]="testSettings['UI.Size'] || 'medium'"
                            [editorId]="selectedEditorId"
                            [settings]="testSettings"
                            [runtimeOverrides]="activeOverrides">
                        </app-dynamic-field>
                    </div>
                      
                    <div class="test-output">
                        <strong>Current Value:</strong>
                        <pre>{{ testValue | json }}</pre>
                    </div>
                </div>
            </div>

            @if (showTestSidebar) {
                <aside class="test-sidebar">
                    <div class="sidebar-header">
                        <h4>Settings</h4>
                    </div>
                    <div class="sidebar-body">
                        <div class="settings-list">
                            @for (group of groupedSettings; track group.fieldName) {
                                <div class="field-setting-group">
                                    @if (group.fieldName !== '*') {
                                        <div class="field-header">[{{ group.fieldName }}]</div>
                                    }
                                    @for (def of group.settings; track def.id) {
                                        <div class="setting-item">
                                            <div class="setting-label-row">
                                                <label>{{ def.name }}</label>
                                                <small class="setting-id">{{ def.id }}</small>
                                            </div>
                                            <app-dynamic-field
                                                [typeId]="def.typeId"
                                                [value]="getTestOverrideValue(group.fieldName, def.id)"
                                                (valueChange)="updateTestOverride(group.fieldName, def.id, $event)"
                                                size="small"
                                                mode="edit">
                                            </app-dynamic-field>
                                        </div>
                                    }
                                </div>
                            }
                            @if (groupedSettings.length === 0) {
                                <div class="empty-settings">No settings published by this editor or its fields.</div>
                            }
                        </div>
                    </div>
                </aside>
            }
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .type-manager {
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 20px;
    }
    .toolbar {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    .spacer { flex-grow: 1; }
    
    button {
        cursor: pointer;
        padding: 6px 12px;
        border-radius: 4px;
        border: 1px solid #ccc;
        background: #f9f9f9;
    }
    .primary-btn {
        background: #2196F3;
        color: white;
        border: none;
        font-weight: bold;
    }
    
    .type-table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        text-align: left;
        padding: 10px;
        border-bottom: 1px solid #eee;
    }
    th {
        background: #f5f5f5;
        font-weight: 600;
        color: #555;
    }
    
    .badge {
        padding: 2px 6px;
        border-radius: 10px;
        font-size: 11px;
    }
    .badge.Core { background: #e3f2fd; color: #1976D2; }
    .badge.Basic { background: #fff3e0; color: #F57C00; }
    .badge.List { background: #e8f5e9; color: #388E3C; }
    .badge.Struct { background: #f3e5f5; color: #7B1FA2; }
    
    .tag { font-size: 11px; text-transform: uppercase; font-weight: bold; color: #888; }
    .tag.user { background: #4CAF50; color: white; }
    .tag.system { background: #9E9E9E; color: white; }
    
    .test-btn {
      background: #2196F3;
      color: white;
      border: none;
      padding: 4px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      margin-left: 5px;
    }
    .test-btn:hover {
      background: #1976D2;
    }
    
    .edit-btn {
      background: #FF9800;
      color: white;
      border: none;
      padding: 4px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
    }
    .edit-btn:hover {
      background: #F57C00;
    }
        
    .delete-btn { background: #ffebee; color: #d32f2f; border: 1px solid #ffcdd2; margin-left: 5px; }
    .delete-btn.disabled { opacity: 0.5; cursor: not-allowed; background: #eee; color: #999; border-color: #ddd; }

    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    
    .modal-content {
      background: white;
      border-radius: 8px;
      padding: 0;
      min-width: 500px;
      max-width: 800px;
      max-height: 80vh;
      overflow: auto;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px;
      border-bottom: 1px solid #eee;
    }
    
    .modal-header h3 {
      margin: 0;
    }
    
    .close-btn {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #999;
    }
    .close-btn:hover {
      color: #333;
    }
    
    .modal-body {
      padding: 20px;
    }
    
    .test-output {
      margin-top: 20px;
      padding: 15px;
      background: #f5f5f5;
      border-radius: 4px;
      font-family: monospace;
      font-size: 12px;
    }
    .test-output pre {
      margin: 5px 0 0 0;
      white-space: pre-wrap;
    }

    /* Enhanced Test Modal */
    .test-modal-content {
      background: white;
      border-radius: 8px;
      display: flex;
      width: 90vw;
      max-width: 600px;
      height: 80vh;
      overflow: hidden;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      transition: max-width 0.3s ease;
    }
    .test-modal-content.with-sidebar {
      max-width: 1000px;
    }
    .test-modal-main {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .test-preview-area {
      flex: 1;
      padding: 30px;
      overflow-y: auto;
      background: #fdfdfd;
    }
    .test-field-container {
        padding: 40px;
        background: white;
        border: 1px solid #eee;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.02);
    }
    .header-actions { display: flex; gap: 10px; align-items: center; }
    .sidebar-toggle { 
        padding: 6px 12px; font-size: 12px; border: 1px solid #2196F3; color: #2196F3;
        background: transparent; border-radius: 4px; cursor: pointer;
    }
    .sidebar-toggle.active { background: #e3f2fd; }

    .test-sidebar {
        width: 320px;
        border-left: 1px solid #eee;
        background: #f9f9f9;
        display: flex;
        flex-direction: column;
    }
    .sidebar-header { padding: 15px 20px; border-bottom: 1px solid #eee; background: #fff; }
    .sidebar-header h4 { margin: 0; font-size: 14px; color: #555; }
    .sidebar-body { flex: 1; padding: 20px; overflow-y: auto; }
    
    .setting-group { margin-bottom: 20px; }
    .setting-group label { display: block; font-size: 12px; font-weight: bold; color: #888; margin-bottom: 5px; text-transform: uppercase; }
    .setting-group select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }

    .setting-item { margin-bottom: 15px; }
    .setting-item label { display: block; font-size: 13px; margin-bottom: 5px; color: #444; }

    .empty-settings { color: #999; font-size: 12px; font-style: italic; text-align: center; margin-top: 20px; }
    .filter-check { display: flex; align-items: center; gap: 5px; font-size: 13px; color: #666; cursor: pointer; }

    .field-setting-group { margin-bottom: 25px; border-bottom: 1px solid #eee; padding-bottom: 15px; }
    .field-setting-group:last-child { border-bottom: none; }
    .field-header { font-weight: bold; font-size: 12px; color: #2196F3; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
    .setting-label-row { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px; }
    .setting-id { color: #999; font-size: 10px; font-family: monospace; }
  `]
})
export class BBTypeListComponent implements OnInit {
  @Input() appConfig: AppConfig | null = null;
  @Output() appConfigChange = new EventEmitter<AppConfig>();

  types$: Observable<BBType[]>;
  view: 'list' | 'create' = 'list';
  editingType: BBType | null = null;
  hideSystemTypes = true;

  // Test Editor State
  testingType: BBType | null = null;
  testValue: any = null;
  showTestSidebar = false;
  selectedEditorId = 'default';
  testSettings: Record<string, any> = {};

  get groupedSettings(): { fieldName: string, settings: BBSettingDefinition[] }[] {
    const type = this.testingType;
    if (!type || !this.selectedEditorId) return [];

    const results: { fieldName: string, settings: BBSettingDefinition[] }[] = [];

    // 1. Root editor settings
    let rootEditor = (type.editors || []).find(e => e.id === this.selectedEditorId);
    if (!rootEditor) {
      rootEditor = type.editors.find(e => e.id === 'default') || type.editors[0];
    }
    if (rootEditor?.settingDefinitions?.length) {
      // Sort: Put Settings ending in ".Editor" at the top
      const sortedSettings = [...rootEditor.settingDefinitions].sort((a, b) => {
        const aIsEditor = a.id.endsWith('.Editor');
        const bIsEditor = b.id.endsWith('.Editor');
        if (aIsEditor && !bIsEditor) return -1;
        if (!aIsEditor && bIsEditor) return 1;
        return 0;
      });
      results.push({ fieldName: '*', settings: sortedSettings });
    }

    // 2. Discover sub-field settings
    if (type.fields) {
      for (const field of type.fields) {
        const fieldType = this.bbTypeService.getTypes().find(t => t.id === field.typeId);
        if (fieldType) {
          let defaultEditor = fieldType.editors.find(e => e.id === 'default') || fieldType.editors[0];
          if (defaultEditor?.settingDefinitions?.length) {
            results.push({ fieldName: field.name, settings: defaultEditor.settingDefinitions });
          }
        }
      }
    } else if (type.baseType === 'List' || type.baseType === 'Dict') {
      const subType = this.bbTypeService.getTypes().find(t => t.id === type.subtypeId);
      if (subType) {
        const defaultEditor = subType.editors.find(e => e.id === 'default') || subType.editors[0];
        if (defaultEditor?.settingDefinitions?.length) {
          results.push({ fieldName: 'item', settings: defaultEditor.settingDefinitions });
        }
      }
    }

    return results;
  }

  constructor(private bbTypeService: BBTypeService) {
    this.types$ = this.bbTypeService.types$.pipe(
      map(types => {
        let baseTypes = types.filter(t => !t.isAnonymous);

        if (this.hideSystemTypes) {
          baseTypes = baseTypes.filter(t => t.userDefined || t.baseType === 'Core');
        }

        if (this.appConfig) {
          // Merge system types with app-specific custom types
          const systemTypes = baseTypes.filter(t => !t.userDefined);
          return [...systemTypes, ...this.appConfig.types.filter(t => !t.isAnonymous)];
        }
        return baseTypes;
      })
    );
  }

  onFilterChange() {
    // Re-trigger observable if needed, but it's already piped to bbTypeService.types$
    // We can manually trigger it by adding an update subject if we want immediate UI refresh without service change
    // But actually, just changing hideCoreTypes will be picked up on next emission.
    // To force it, we can use a combineLatest with a refresh subject.
    this.bbTypeService['typesSubject'].next(this.bbTypeService.getTypes());
  }

  ngOnInit() { }

  editType(type: BBType) {
    this.editingType = type;
    this.view = 'create';
  }

  cancelEdit() {
    this.editingType = null;
    this.view = 'list';
  }

  resetAll() {
    if (confirm('Are you sure you want to clear ALL custom types? This cannot be undone.')) {
      if (this.appConfig) {
        this.appConfig.types = [];
        this.appConfigChange.emit(this.appConfig);
      } else {
        this.bbTypeService.clearAllTypes();
      }
    }
  }

  onTypeCreated(newType: BBType) {
    if (this.appConfig) {
      if (this.editingType) {
        const index = this.appConfig.types.findIndex(t => t.id === newType.id);
        if (index >= 0) this.appConfig.types[index] = newType;
        this.editingType = null;
      } else {
        this.appConfig.types.push(newType);
      }
      this.appConfigChange.emit(this.appConfig);
    } else {
      if (this.editingType) {
        this.bbTypeService.updateType(newType);
        this.editingType = null;
      } else {
        this.bbTypeService.addType(newType);
      }
    }
    this.view = 'list';
  }

  getTypeName(id?: string): string {
    if (!id) return '?';
    const types = this.bbTypeService.getTypes();
    const t = types.find(x => x.id === id) || types.find(x => x.id.toLowerCase() === id.toLowerCase());

    if (t && t.isAnonymous) {
      return `Anonymous ${t.baseType}`;
    }
    return t ? t.name : id;
  }

  openTestEditor(type: BBType) {
    this.testingType = type;
    this.testValue = this.getDefaultValue(type);
    this.selectedEditorId = type.editors?.[0]?.id || 'default';
    this.testSettings = {
      'UI.EditMode': 'edit',
      'UI.Size': 'medium'
    };
    this.activeOverrides = [];

    // Pre-populate the editor selection override so the sidebar dropdown is synced
    const editorSetting = (type.editors?.[0]?.settingDefinitions || []).find(d => d.id.endsWith('.Editor'));
    if (editorSetting) {
      this.activeOverrides.push({ fieldName: '*', settingId: editorSetting.id, value: this.selectedEditorId });
    }

    this.showTestSidebar = false;
  }

  closeTestEditor() {
    this.testingType = null;
    this.testValue = null;
    this.testSettings = {};
    this.activeOverrides = [];
  }


  getTestOverrideValue(fieldName: string, settingId: string): any {
    const override = this.activeOverrides.find(o => o.fieldName === fieldName && o.settingId === settingId);
    if (override) return override.value;

    // Use intrinsic field value if it's a root setting matching a BBType property
    if (fieldName === '*' && this.testingType) {
      const parts = settingId.split('.');
      const propName = parts.length > 1 ? parts[1] : parts[0];
      // Lowercase the first char to match BBType property names (e.g. MaxLen -> maxLen)
      const camelProp = propName.charAt(0).toLowerCase() + propName.slice(1);

      if (camelProp in this.testingType) {
        let val = (this.testingType as any)[camelProp];
        // Special case: if it's a number/boolean expected by the editor but stored as 1/0
        return val;
      }
    }
    return undefined;
  }

  activeOverrides: any[] = []; // BBSettingOverride[]

  updateTestOverride(fieldName: string, settingId: string, value: any) {
    const idx = this.activeOverrides.findIndex(o => o.fieldName === fieldName && o.settingId === settingId);
    if (idx >= 0) {
      if (value === null || value === undefined) this.activeOverrides.splice(idx, 1);
      else this.activeOverrides[idx].value = value;
    } else if (value !== null && value !== undefined) {
      this.activeOverrides.push({ fieldName, settingId, value });
    }

    // Sync editor variant if settingId is an Editor setting for the root
    if (fieldName === '*' && settingId.endsWith('.Editor')) {
      this.selectedEditorId = value;
    }

    this.refreshTestSettings();
  }

  refreshTestSettings() {
    this.testSettings = { ...this.testSettings, _refresh: Date.now() };
  }

  getDefaultValue(type: BBType): any {
    if (type.baseType === 'Struct' || type.baseType === 'Union' || type.baseType === 'Dict') {
      return {};
    } else if (type.baseType === 'List') {
      return [];
    } else if (type.values && type.values.length > 0) {
      return null; // Enum - no default
    } else {
      // Core types
      const root = type.baseType === 'Core' ? type.name : undefined;
      switch (root) {
        case 'String': return '';
        case 'Int': return 0;
        case 'Boolean': return false;
        case 'File': return null;
        case 'Date': return null;
        case 'Dict': return {};
        default: return null;
      }
    }
  }

  isTypeRef(id: string): boolean {
    return this.bbTypeService.isTypeReferenced(id);
  }

  getRefNames(id: string): string {
    const refs = this.bbTypeService.getTypesReferencing(id);
    return refs.map(t => t.name).join(', ');
  }

  deleteType(type: BBType) {
    if (confirm(`Delete type "${type.name}"?`)) {
      if (this.appConfig) {
        this.appConfig.types = this.appConfig.types.filter(t => t.id !== type.id);
        this.appConfigChange.emit(this.appConfig);
      } else {
        this.bbTypeService.deleteType(type.id);
      }
    }
  }

  downloadConfig() {
    const types = this.appConfig ? this.appConfig.types : this.bbTypeService.getTypes().filter(t => t.userDefined);
    const filename = this.appConfig ? `${this.appConfig.slug}-types.json` : "bb-types-config.json";
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(types, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", filename);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  }

  loadConfig(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e: any) => {
      try {
        const types = JSON.parse(e.target.result);
        if (this.appConfig) {
          this.appConfig.types = [...this.appConfig.types, ...types];
          this.appConfigChange.emit(this.appConfig);
        } else {
          this.bbTypeService.importTypes(types);
        }
      } catch (err) {
        console.error('Invalid JSON', err);
        alert('Failed to load JSON');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  }
}
