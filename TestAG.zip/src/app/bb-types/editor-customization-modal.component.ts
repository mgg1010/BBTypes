import { Component, EventEmitter, Input, Output, OnInit, Type } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BBEditor, BBSettingOverride, BBType, BBSettingDefinition } from '../models/bb-types';
import { DynamicFieldComponent } from '../shared/dynamic-field.component';
import { BBTypeService } from '../services/bb-type.service';

interface SystemSettingDef {
  id: string;
  name: string;
  description: string;
}

@Component({
  selector: 'app-editor-customization-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, DynamicFieldComponent],
  template: `
    <div class="customizer-container resizable-modal">
      <div class="resize-handle"></div>
      <div class="header">
        <h3>Customize Editor: {{ editor.name }}</h3>
        <button class="close-btn" (click)="close.emit()">✕</button>
      </div>

      <nav class="tabs">
        <button [class.active]="activeTab === 'core'" (click)="activeTab = 'core'">Core Settings</button>
        <button [class.active]="activeTab === 'published'" (click)="activeTab = 'published'">Published Settings</button>
        <button [class.active]="activeTab === 'overrides'" (click)="activeTab = 'overrides'">Overrides</button>
      </nav>

      <div class="tab-content" [class.with-sidebar]="activeTab === 'overrides'">
        <!-- Core Tab -->
        @if (activeTab === 'core') {
          <div class="core-tab">
            <div class="form-group">
              <label>Name:</label>
              <input [(ngModel)]="editor.name">
            </div>
            <div class="form-group">
              <label>ID:</label>
              <input [(ngModel)]="editor.id" [disabled]="editor.type === 'System'">
            </div>
            <div class="form-group">
              <label>Base Editor ID:</label>
              <input [(ngModel)]="editor.baseEditorId" placeholder="e.g. vertical">
            </div>
          </div>
        }

        <!-- Published Tab -->
        @if (activeTab === 'published') {
          <div class="published-tab">
            <p class="help-text">Settings published here will be visible for overrides in parent types using this editor.</p>
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>ID</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                @for (def of editor.settingDefinitions || []; track def.id) {
                    <tr>
                        <td><input [(ngModel)]="def.name" style="width: 100px"></td>
                        <td><code>{{ def.id }}</code></td>
                        <td>
                            <select [(ngModel)]="def.typeId">
                                <option value="string">String</option>
                                <option value="number">Number</option>
                                <option value="boolean">Boolean</option>
                            </select>
                        </td>
                        <td>
                            <select [(ngModel)]="editor.publishedSettings[def.id]">
                                <option value="published">Published</option>
                                <option value="hidden">Hidden</option>
                            </select>
                        </td>
                        <td><button class="icon-btn delete" (click)="removePublishedDef(def.id)">🗑️</button></td>
                    </tr>
                }
              </tbody>
            </table>
            <div class="add-row">
              <input #newPubId placeholder="ID (e.g. UI.Label)">
              <button class="add-btn" (click)="addPublishedDef(newPubId.value); newPubId.value = ''" [disabled]="!newPubId.value">+ Add Setting</button>
            </div>
          </div>
        }

        <!-- Overrides Tab -->
        @if (activeTab === 'overrides') {
          <div class="overrides-container">
            <div class="overrides-main">
                <p class="help-text">Define specific values for settings. Use "*" for all fields, or match field names.</p>
                <div class="overrides-table-wrapper">
                    <table>
                      <thead>
                        <tr>
                          <th>Field</th>
                          <th>Setting</th>
                          <th>Value</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        @for (ov of editor.overrides; track $index) {
                          <tr [class.expr-mode]="ov.isExpression">
                            <td>
                                <select [(ngModel)]="ov.fieldName" class="field-select">
                                    <option value="*">* (All)</option>
                                    @for (field of parentFields; track field.name) {
                                        <option [value]="field.name">{{ field.name }}</option>
                                    }
                                </select>
                            </td>
                            <td>
                                <select [(ngModel)]="ov.settingId" (ngModelChange)="onSettingChanged(ov)" class="setting-select">
                                    <option value="">Select Setting...</option>
                                    @for (opt of availableSettings; track opt.id) {
                                        <option [value]="opt.id">{{ opt.name }} ({{ opt.id }})</option>
                                    }
                                </select>
                            </td>
                            <td>
                                <div class="value-engine">
                                    @if (ov.isExpression) {
                                        <textarea 
                                            class="expr-box" 
                                            [(ngModel)]="ov.value" 
                                            placeholder="e.g. =Parent.Prop"
                                            (dragover)="$event.preventDefault()"
                                            (drop)="onExprDrop($event, ov)"></textarea>
                                    } @else {
                                        <div class="lit-box">
                                            @if (ov.settingId) {
                                                <app-dynamic-field
                                                    [typeId]="getSettingType(ov.settingId)"
                                                    [value]="ov.value"
                                                    (valueChange)="ov.value = $event"
                                                    size="small"
                                                    mode="edit">
                                                </app-dynamic-field>
                                            } @else {
                                                <input [(ngModel)]="ov.value" placeholder="Value">
                                            }
                                        </div>
                                    }
                                    <button class="toggle-mode-btn" [class.active]="ov.isExpression" (click)="ov.isExpression = !ov.isExpression" title="Toggle Expression Mode">
                                        {{ ov.isExpression ? 'f(x)' : 'Abc' }}
                                    </button>
                                </div>
                            </td>
                            <td><button class="icon-btn delete" (click)="removeOverride($index)">🗑️</button></td>
                          </tr>
                        }
                      </tbody>
                    </table>
                </div>
                <button class="add-btn" (click)="addOverride()">+ Add Override</button>
            </div>

            <aside class="overrides-sidebar">
                <h4>Draggable Context</h4>
                <p class="sidebar-help">Drag these settings into an expression box to link them.</p>
                <div class="chip-list">
                    @for (settingId of publishedKeys; track settingId) {
                        <div class="setting-chip" 
                             draggable="true" 
                             (dragstart)="onChipDragStart($event, settingId)">
                            <span class="chip-label">{{ settingId }}</span>
                            <span class="chip-handle">⋮⋮</span>
                        </div>
                    }
                    @if (publishedKeys.length === 0) {
                        <div class="empty-state">No published settings to drag.</div>
                    }
                </div>
            </aside>
          </div>
        }
      </div>

      <div class="footer">
        <button class="save-btn" (click)="save.emit(editor)">Apply Changes</button>
      </div>
    </div>
  `,
  styles: [`
    .customizer-container { display: flex; flex-direction: column; height: 100%; max-height: 90vh; width: 95vw; max-width: 1000px; }
    .header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #eee; }
    .header h3 { margin: 0; color: #333; }
    .close-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #999; }
    
    .tabs { display: flex; padding: 0 20px; background: #fafafa; border-bottom: 1px solid #eee; }
    .tabs button { 
      padding: 12px 20px; background: none; border: none; border-bottom: 2px solid transparent; 
      cursor: pointer; color: #666; font-weight: 500;
    }
    .tabs button.active { color: #2196F3; border-bottom-color: #2196F3; }

    .tab-content { flex: 1; padding: 20px; overflow-y: auto; background: #fff; }
    .tab-content.with-sidebar { padding: 0; }
    .help-text { color: #666; font-size: 13px; font-style: italic; margin-bottom: 15px; }

    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 14px; }
    .form-group input { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }

    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; padding: 10px; border-bottom: 2px solid #eee; font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; }
    td { padding: 8px 10px; border-bottom: 1px solid #eee; vertical-align: middle; }
    input, select { padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; }
    code { background: #f5f5f5; padding: 2px 4px; border-radius: 3px; font-family: monospace; font-size: 12px; }

    .add-row { margin-top: 15px; display: flex; gap: 10px; align-items: center; }
    .add-row input { flex: 1; }

    .overrides-container { display: grid; grid-template-columns: 1fr 280px; height: 100%; min-height: 400px; }
    .overrides-main { padding: 20px; overflow-y: auto; border-right: 1px solid #eee; }
    .overrides-sidebar { padding: 20px; background: #fbfbfb; }
    .overrides-sidebar h4 { margin-top: 0; font-size: 14px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px; }
    .sidebar-help { font-size: 11px; color: #888; margin-bottom: 15px; }

    .field-select, .setting-select { width: 100%; }
    .value-engine { display: flex; gap: 5px; align-items: flex-start; }
    .expr-box { flex: 1; min-height: 60px; font-family: monospace; font-size: 12px; padding: 8px; border: 1px solid #bbdefb; background: #f1f8fe; resize: vertical; }
    .lit-box { flex: 1; min-width: 150px; }
    
    .toggle-mode-btn { 
        padding: 4px 8px; font-size: 11px; background: #eee; border: 1px solid #ccc; border-radius: 4px; 
        cursor: pointer; height: 30px; align-self: center;
    }
    .toggle-mode-btn.active { background: #e3f2fd; border-color: #2196F3; color: #1976d2; font-weight: bold; }

    .setting-chip { 
        display: flex; justify-content: space-between; align-items: center;
        background: #fff; border: 1px solid #e0e0e0; border-radius: 16px;
        padding: 6px 12px; margin-bottom: 8px; cursor: grab;
        font-size: 12px; color: #444; transition: all 0.2s;
    }
    .setting-chip:hover { border-color: #2196F3; background: #f5faff; }
    .chip-handle { color: #ccc; font-size: 14px; }
    
    .empty-state { text-align: center; color: #999; font-size: 12px; padding: 20px 0; }

    .footer { padding: 15px 20px; border-top: 1px solid #eee; display: flex; justify-content: flex-end; }
    .save-btn { background: #2196F3; color: white; border: none; padding: 10px 20px; border-radius: 4px; font-weight: bold; cursor: pointer; }
    .add-btn { background: #4CAF50; color: white; border: none; padding: 8px 16px; border-radius: 4px; margin-top: 15px; cursor: pointer; }
    .icon-btn { background: none; border: none; cursor: pointer; padding: 4px; font-size: 16px; opacity: 0.6; }
    .icon-btn:hover { opacity: 1; }
    .icon-btn.delete { color: #d32f2f; }
  `]
})
export class EditorCustomizationModalComponent implements OnInit {
  @Input() editor!: BBEditor;
  @Input() parentType!: BBType;
  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<BBEditor>();

  activeTab: 'core' | 'published' | 'overrides' = 'core';

  constructor(private bbTypeService: BBTypeService) { }

  get publishedKeys() {
    return Object.keys(this.editor.publishedSettings || {});
  }

  get parentFields() {
    return this.parentType.fields || [];
  }

  get availableSettings(): BBSettingDefinition[] {
    return this.bbTypeService.getAvailableSettings(this.parentType);
  }

  ngOnInit() {
    // Clone editor to avoid direct mutation until save
    this.editor = JSON.parse(JSON.stringify(this.editor));
    if (!this.editor.publishedSettings) this.editor.publishedSettings = {};
    if (!this.editor.settingDefinitions) this.editor.settingDefinitions = [];
    if (!this.editor.overrides) this.editor.overrides = [];
  }

  addPublishedDef(id: string) {
    if (!id) return;
    if (!this.editor.settingDefinitions) this.editor.settingDefinitions = [];

    const existing = this.editor.settingDefinitions.find(d => d.id === id);
    if (!existing) {
      this.editor.settingDefinitions.push({
        id,
        name: id.split('.').pop() || id,
        typeId: 'string'
      });
      this.editor.publishedSettings[id] = 'published';
    }
  }

  removePublishedDef(id: string) {
    this.editor.settingDefinitions = (this.editor.settingDefinitions || []).filter(d => d.id !== id);
    delete this.editor.publishedSettings[id];
  }

  getSettingType(settingId: string): string {
    const def = this.availableSettings.find(s => s.id === settingId);
    return def?.typeId || 'string';
  }

  onSettingChanged(ov: any) {
    // Reset value if type changed? 
    // For now just ensure it's not undefined
    if (ov.value === undefined) ov.value = '';
  }

  addOverride() {
    this.editor.overrides.push({
      fieldName: '*',
      settingId: '',
      value: ''
    });
  }

  removeOverride(index: number) {
    this.editor.overrides.splice(index, 1);
  }

  // Drag & Drop logic
  onChipDragStart(event: DragEvent, settingId: string) {
    event.dataTransfer?.setData('text/plain', `[${settingId}]`);
    if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copy';
  }

  onExprDrop(event: DragEvent, ov: any) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('text/plain');
    if (data && ov.isExpression) {
      const start = (event.target as HTMLTextAreaElement).selectionStart || 0;
      const end = (event.target as HTMLTextAreaElement).selectionEnd || 0;
      const text = ov.value || '';
      ov.value = text.substring(0, start) + data + text.substring(end);
    }
  }
}
