import { BBType } from '../models/bb-types';

export const INITIAL_CORE_TYPES: BBType[] = [
    // Helper types for editor selection (Hidden in list by default)
    {
        id: 'String.Editor',
        name: 'String.Editor',
        baseType: 'Basic',
        subtypeId: 'string',
        userDefined: false,
        isAnonymous: false,
        values: [
            { id: 'default', text: 'Default' }
        ],
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'enum', publishedSettings: {}, settingDefinitions: [], overrides: [] }]
    },
    {
        id: 'Boolean.Editor',
        name: 'Boolean.Editor',
        baseType: 'Basic',
        subtypeId: 'string',
        userDefined: false,
        isAnonymous: false,
        values: [
            { id: 'default', text: 'Checkbox' },
            { id: 'radio', text: 'Radio' },
            { id: 'dropdown', text: 'Dropdown' }
        ],
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'enum', publishedSettings: {}, settingDefinitions: [], overrides: [] }]
    },
    {
        id: 'Number.Editor',
        name: 'Number.Editor',
        baseType: 'Basic',
        subtypeId: 'string',
        userDefined: false,
        isAnonymous: false,
        values: [
            { id: 'default', text: 'Default' }
        ],
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'enum', publishedSettings: {}, settingDefinitions: [], overrides: [] }]
    },

    // Validation Helper Types
    {
        id: 'String.ValidationRule',
        name: 'String.ValidationRule',
        baseType: 'Struct',
        userDefined: false,
        isAnonymous: false,
        fields: [
            { name: 'Regexp', typeId: 'string' },
            { name: 'ErrMsg', typeId: 'string' }
        ],
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'struct', publishedSettings: {}, settingDefinitions: [], overrides: [] }]
    },
    {
        id: 'String.ValidationRules',
        name: 'String.ValidationRules',
        baseType: 'List',
        subtypeId: 'String.ValidationRule',
        userDefined: false,
        isAnonymous: true,
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'list', publishedSettings: {}, settingDefinitions: [], overrides: [] }]
    },

    {
        id: 'string',
        name: 'String',
        baseType: 'Core',
        userDefined: false,
        // Intrinsic fields
        validationRules: [],
        maxLen: 100000,
        maxLenMsg: 'Must be %d characters or less',
        minLen: 0,
        minLenMsg: 'Must be %d characters or more',
        editors: [{
            id: 'default',
            name: 'Default',
            type: 'System',
            baseEditorId: 'string',
            publishedSettings: {
                'String.UpperCase': 'published',
                'String.Editor': 'published',
                'String.MaxLen': 'published',
                'String.MaxLenMsg': 'published',
                'String.MinLen': 'published',
                'String.MinLenMsg': 'published',
                'String.ValidationRules': 'published'
            },
            settingDefinitions: [
                { id: 'String.Editor', name: 'Editor', typeId: 'String.Editor' },
                { id: 'String.UpperCase', name: 'Upper Case', typeId: 'boolean' },
                { id: 'String.MaxLen', name: 'Max Length', typeId: 'number' },
                { id: 'String.MaxLenMsg', name: 'Max Length Error', typeId: 'string' },
                { id: 'String.MinLen', name: 'Min Length', typeId: 'number' },
                { id: 'String.MinLenMsg', name: 'Min Length Error', typeId: 'string' },
                { id: 'String.ValidationRules', name: 'Validation Rules', typeId: 'String.ValidationRules' }
            ],
            overrides: []
        }]
    },
    {
        id: 'number',
        name: 'Number', // Renamed from Int
        baseType: 'Core',
        userDefined: false,
        // Intrinsic fields
        allowNegative: true,
        allowNegativeMsg: 'Number cannot be negative',
        allowDecimals: true,
        allowDecimalsMsg: 'Number cannot be a decimal',
        allowScientific: false,
        allowScientificMsg: 'Number cannot use scientific notation',
        editors: [{
            id: 'default',
            name: 'Default',
            type: 'System',
            baseEditorId: 'number',
            publishedSettings: {
                'Number.Editor': 'published',
                'Number.AllowNegative': 'published',
                'Number.AllowNegativeMsg': 'published',
                'Number.AllowDecimals': 'published',
                'Number.AllowDecimalsMsg': 'published',
                'Number.AllowScientific': 'published',
                'Number.AllowScientificMsg': 'published'
            },
            settingDefinitions: [
                { id: 'Number.Editor', name: 'Editor', typeId: 'Number.Editor' },
                { id: 'Number.AllowNegative', name: 'Allow Negative', typeId: 'boolean' },
                { id: 'Number.AllowNegativeMsg', name: 'Allow Negative Error', typeId: 'string' },
                { id: 'Number.AllowDecimals', name: 'Allow Decimals', typeId: 'boolean' },
                { id: 'Number.AllowDecimalsMsg', name: 'Allow Decimals Error', typeId: 'string' },
                { id: 'Number.AllowScientific', name: 'Allow Scientific', typeId: 'boolean' },
                { id: 'Number.AllowScientificMsg', name: 'Allow Scientific Error', typeId: 'string' }
            ],
            overrides: []
        }]
    },
    {
        id: 'boolean',
        name: 'Boolean',
        baseType: 'Core',
        userDefined: false,
        values: [
            { id: 1, text: 'True' },
            { id: 0, text: 'False' }
        ],
        editors: [
            {
                id: 'default',
                name: 'Checkbox',
                type: 'System',
                baseEditorId: 'checkbox',
                publishedSettings: { 'Boolean.Editor': 'published' },
                settingDefinitions: [
                    { id: 'Boolean.Editor', name: 'Editor', typeId: 'Boolean.Editor', description: 'Selection between Checkbox, Radio, or Dropdown' }
                ],
                overrides: []
            },
            {
                id: 'radio',
                name: 'Radio',
                type: 'System',
                baseEditorId: 'radio',
                publishedSettings: { 'Boolean.Editor': 'published' },
                settingDefinitions: [
                    { id: 'Boolean.Editor', name: 'Editor', typeId: 'Boolean.Editor' }
                ],
                overrides: []
            },
            {
                id: 'dropdown',
                name: 'Dropdown',
                type: 'System',
                baseEditorId: 'enum',
                publishedSettings: { 'Boolean.Editor': 'published' },
                settingDefinitions: [
                    { id: 'Boolean.Editor', name: 'Editor', typeId: 'Boolean.Editor' }
                ],
                overrides: []
            }
        ]
    },
    {
        id: 'file',
        name: 'File',
        baseType: 'Core',
        userDefined: false,
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'file', publishedSettings: { 'File.Editor': 'published' }, settingDefinitions: [{ id: 'File.Editor', name: 'Editor', typeId: 'String.Editor' }], overrides: [] }]
    },
    {
        id: 'date',
        name: 'Date',
        baseType: 'Core',
        userDefined: false,
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'date', publishedSettings: { 'Date.Editor': 'published' }, settingDefinitions: [{ id: 'Date.Editor', name: 'Editor', typeId: 'String.Editor' }], overrides: [] }]
    },
    {
        id: 'dict',
        name: 'Dict',
        baseType: 'Core',
        userDefined: false,
        subtypeId: 'string',
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'dict', publishedSettings: { 'Dict.Editor': 'published' }, settingDefinitions: [{ id: 'Dict.Editor', name: 'Editor', typeId: 'String.Editor' }], overrides: [] }]
    },
    // Base types are now implicitly handled or should be hidden
    {
        id: 'struct-base',
        name: 'Struct Base',
        baseType: 'Struct',
        userDefined: false,
        isAnonymous: true,
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'struct', publishedSettings: { 'Struct.Editor': 'published' }, settingDefinitions: [{ id: 'Struct.Editor', name: 'Editor', typeId: 'String.Editor' }], overrides: [] }]
    },
    {
        id: 'list-base',
        name: 'List Base',
        baseType: 'List',
        userDefined: false,
        isAnonymous: true,
        subtypeId: 'string',
        editors: [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'list', publishedSettings: { 'List.Editor': 'published' }, settingDefinitions: [{ id: 'List.Editor', name: 'Editor', typeId: 'String.Editor' }], overrides: [] }]
    }
];
