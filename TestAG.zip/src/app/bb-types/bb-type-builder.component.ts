import { Component, EventEmitter, Output, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BBTypeService } from '../services/bb-type.service';
import { BBType, BBTypeBase, BBField, BBValue, BBEditor, BBSettingOverride } from '../models/bb-types';
import { AppConfig } from '../models/app-models';

import { BBTypeBuilderComponent as Self } from './bb-type-builder.component';
import { forwardRef } from '@angular/core';
import { EditorCustomizationModalComponent } from './editor-customization-modal.component';

@Component({
  selector: 'app-bb-type-builder',
  standalone: true,
  imports: [CommonModule, FormsModule, EditorCustomizationModalComponent, forwardRef(() => Self)],
  template: `
    <div class="builder-container">
      <h3>{{ editingType ? 'Edit Type: ' + editingType.name : 'Create New Type' }}</h3>
      
      <nav class="builder-tabs">
        <button [class.active]="activeTab === 'definition'" (click)="activeTab = 'definition'">Type Definition</button>
        <button [class.active]="activeTab === 'editors'" (click)="activeTab = 'editors'">Editors</button>
      </nav>

      <div class="tab-content">
        @if (activeTab === 'definition') {
          <div class="definition-tab">
            <!-- header -->
            @if (!isAnonymousMode) {
              <div class="form-row">
                  <label>
                      Type Name:
                      <input [(ngModel)]="newType.name" placeholder="e.g. My Custom List">
                  </label>
                  
                  <label>
                      Kind:
                      <select [(ngModel)]="baseTypeSelection" (change)="onBaseTypeChange()">
                          <option value="Basic">Basic (Enum/Refinement)</option>
                          <option value="List">List</option>
                          <option value="Struct">Struct</option>
                          <option value="Union">Union</option>
                          <option value="Dict">Dict (Dynamic Struct)</option>
                      </select>
                  </label>
              </div>
            } @else {
              <div class="form-row">
                  <label>
                      Kind:
                      <select [(ngModel)]="baseTypeSelection" (change)="onBaseTypeChange()">
                          <option value="Basic">Basic (Enum/Refinement)</option>
                          <option value="List">List</option>
                          <option value="Struct">Struct</option>
                          <option value="Union">Union</option>
                          <option value="Dict">Dict (Dynamic Struct)</option>
                      </select>
                  </label>
              </div>
            }
            
            <hr>
            
            <!-- Basic Config -->
            @if (baseTypeSelection === 'Basic') {
              <div class="config-section">
                  <h4>Basic Configuration</h4>
                  <label>
                      Based On (Core Type):
                      <select [(ngModel)]="newType.subtypeId"> <!-- Using subtypeId to store core type ref for Basic -->
                          @for (type of coreTypes; track type.id) {
                              <option [value]="type.id">{{ type.name }}</option>
                          }
                      </select>
                  </label>
                  
                  <div class="values-list">
                      <h5>Allowed Values (Enum)</h5>
                      <!-- Simple list editor for values -->
                       @for (val of newType.values || []; track $index) {
                          <div class="flex-row">
                              <input type="number" [(ngModel)]="val.id" placeholder="ID" style="width: 50px">
                              <input type="text" [(ngModel)]="val.text" placeholder="Display Text">
                              <button (click)="removeValue($index)">🗑️</button>
                          </div>
                       }
                       <button (click)="addValue()">+ Add Value</button>
                  </div>
              </div>
            }
            
            <!-- List/Dict Config -->
            @if (baseTypeSelection === 'List' || baseTypeSelection === 'Dict') {
               <div class="config-section">
                  <h4>{{ baseTypeSelection }} Configuration</h4>
                  <label>
                      {{ baseTypeSelection === 'Dict' ? 'Default Entry Type' : 'List Of' }}:
                      @if (isAnonymousType(newType.subtypeId || '')) {
                         <div class="anon-type-container">
                             <span class="anon-type-badge">{{ getAnonymousTypeName(newType.subtypeId!) }}</span>
                             <button class="reset-icon-btn" (click)="newType.subtypeId = (allTypes[0]?.id || '')" title="Change Type">🔄</button>
                         </div>
                      } @else {
                          <select [(ngModel)]="newType.subtypeId" (change)="onListSubtypeChange($event)">
                              @for (type of allTypes; track type.id) {
                                  <option [value]="type.id">{{ type.name }}</option>
                              }
                              <option value="__new_anon__">+ New (anonymous)...</option>
                          </select>
                      }
                  </label>
               </div>
            }
            
            <!-- Struct/Union Config -->
            @if (baseTypeSelection === 'Struct' || baseTypeSelection === 'Union') {
               <div class="config-section">
                  <h4>Fields</h4>
                  
                  @for (field of newType.fields || []; track $index) {
                      <div class="flex-row field-row">
                          <input [(ngModel)]="field.name" placeholder="Field Name">
                          @if (isAnonymousType(field.typeId)) {
                              <div class="anon-type-container">
                                  <span class="anon-type-badge">{{ getAnonymousTypeName(field.typeId) }}</span>
                                  <button class="reset-icon-btn" (click)="field.typeId = (allTypes[0]?.id || '')" title="Change Type">🔄</button>
                              </div>
                          } @else {
                              <select [(ngModel)]="field.typeId" (change)="onFieldTypeChange($event, field)">
                                  @for (type of allTypes; track type.id) {
                                      <option [value]="type.id">{{ type.name }}</option>
                                  }
                                  <option value="__new_anon__">+ New (anonymous)...</option>
                              </select>
                          }
                           <button (click)="removeField($index)">🗑️</button>
                      </div>
                  }
                  <button (click)="addField()">+ Add Field</button>
               </div>
            }
          </div>
        }

        @if (activeTab === 'editors') {
          <div class="editors-tab">
            <div class="editors-list">
              <table>
                <thead>
                  <tr>
                    <th>Editor Name</th>
                    <th>Type</th>
                    <th>Base</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (editor of newType.editors; track editor.id) {
                    <tr>
                      <td>{{ editor.name }}</td>
                      <td><span class="badge" [ngClass]="editor.type">{{ editor.type }}</span></td>
                      <td>{{ editor.baseEditorId || '-' }}</td>
                      <td class="editor-actions">
                        <button class="icon-btn" (click)="customizeEditor(editor)" title="Customize">⚙️</button>
                        <button class="icon-btn" (click)="testEditor(editor)" title="Test">🧪</button>
                        @if (editor.type === 'Custom') {
                          <button class="icon-btn delete" (click)="deleteEditor(editor.id)" title="Delete">🗑️</button>
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
              <button class="add-btn" (click)="addEditor()">+ Add Custom Editor</button>
            </div>
          </div>
        }
      </div>
      
      <!-- Editor Customization Modal -->
      @if (showEditorCustomizer && currentEditingEditor) {
         <div class="modal-overlay">
           <div class="modal-content large">
             <app-editor-customization-modal
               [editor]="currentEditingEditor"
               [parentType]="$any(newType)"
               (close)="showEditorCustomizer = false"
               (save)="onEditorCustomized($event)">
             </app-editor-customization-modal>
           </div>
         </div>
      }

      <!-- Nested Anonymous Builder Modal -->
      @if (showAnonBuilder) {
        <div class="modal-overlay">
          <div class="modal-content">
            <app-bb-type-builder
              [isAnonymousMode]="true"
              [appConfig]="appConfig"
              (cancel)="showAnonBuilder = false"
              (create)="onAnonTypeCreated($event)">
            </app-bb-type-builder>
          </div>
        </div>
      }
      
      <div class="actions footer">
        <button class="cancel-btn" (click)="cancel.emit()">Cancel</button>
        <button class="save-btn" (click)="save()">{{ editingType ? 'Update Type' : 'Create Type' }}</button>
      </div>
    </div>
  `,
  styles: [`
    .builder-container { 
      padding: 20px; 
      background: white; 
      border-radius: 8px; 
      display: flex;
      flex-direction: column;
      max-height: 90vh;
      overflow: hidden;
    }
    .builder-tabs { display: flex; border-bottom: 2px solid #eee; margin-bottom: 20px; }
    .builder-tabs button {
      padding: 10px 20px; background: none; border: none; cursor: pointer;
      font-weight: 600; color: #666; position: relative;
    }
    .builder-tabs button.active { color: #2196F3; }
    .builder-tabs button.active::after {
      content: ''; position: absolute; bottom: -2px; left: 0; right: 0;
      height: 2px; background: #2196F3;
    }

    .tab-content { flex: 1; overflow-y: auto; padding-right: 10px; }

    .form-row { display: flex; gap: 20px; margin-bottom: 15px; }
    .form-row label { display: flex; flex-direction: column; flex: 1; font-weight: bold; font-size: 14px; }
    .form-row input, .form-row select { padding: 8px; border: 1px solid #ccc; border-radius: 4px; margin-top: 5px; }
    
    .config-section { margin-top: 20px; padding: 15px; background: #f9f9f9; border-radius: 6px; }
    .config-section h4 { margin-top: 0; border-bottom: 1px solid #ddd; padding-bottom: 5px; }

    .flex-row { display: flex; gap: 10px; margin-bottom: 10px; align-items: center; }
    .field-row { border-bottom: 1px dashed #eee; padding-bottom: 10px; }
    
    .anon-type-container { 
        display: flex; align-items: center; gap: 5px; background: #e3f2fd; 
        padding: 4px 8px; border-radius: 4px; border: 1px solid #bbdefb;
    }
    .anon-type-badge { font-family: monospace; font-size: 12px; color: #1976d2; font-weight: bold; }
    .reset-icon-btn { background: none; border: none; cursor: pointer; padding: 0; font-size: 14px; }

    .modal-overlay {
      position: fixed; top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.5); display: flex; align-items: center;
      justify-content: center; z-index: 1000;
    }
    .modal-content { 
      background: white; padding: 0; border-radius: 8px; 
      width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;
    }
    .modal-content.large { max-width: 800px; }
    
    .footer { 
      display: flex; justify-content: flex-end; gap: 10px; 
      margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;
    }
    button { padding: 8px 16px; border-radius: 4px; cursor: pointer; border: none; font-weight: 500; }
    .save-btn { background: #2196F3; color: white; }
    .cancel-btn { background: #eee; }
    .add-btn { background: #4CAF50; color: white; margin-top: 10px; }
    .icon-btn { background: #f5f5f5; border: 1px solid #ddd; padding: 4px 8px; font-size: 14px; }
    .icon-btn.delete { color: #d32f2f; }

    .editors-list table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    .editors-list th, .editors-list td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
    .badge { padding: 2px 6px; border-radius: 4px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
    .badge.System { background: #e0e0e0; color: #616161; }
    .badge.Custom { background: #e1f5fe; color: #0288d1; }
    .editor-actions { display: flex; gap: 5px; }
  `]
})
export class BBTypeBuilderComponent implements OnInit, OnDestroy {
  // Input for editing existing types
  @Input() editingType: BBType | null = null;
  @Input() appConfig: AppConfig | null = null;
  @Input() isAnonymousMode = false;
  @Output() cancel = new EventEmitter<void>();
  @Output() create = new EventEmitter<BBType>();

  baseTypeSelection: BBTypeBase = 'Basic';

  // Draft type
  newType: Partial<BBType> = {
    name: '',
    userDefined: true,
    editors: []
  };

  activeTab: 'definition' | 'editors' = 'definition';
  showEditorCustomizer = false;
  currentEditingEditor: BBEditor | null = null;

  coreTypes: BBType[] = [];
  allTypes: BBType[] = [];

  showAnonBuilder = false;
  pendingField: BBField | null = null;
  pendingListSubtype = false;
  private typesSub: any;

  constructor(private bbTypeService: BBTypeService) {
    // Initialization moved to ngOnInit for subscription
  }

  ngOnDestroy() {
    if (this.typesSub) this.typesSub.unsubscribe();
  }

  private getDefaultEditorsForBase(baseKind: BBTypeBase): BBEditor[] {
    let baseTypeId = '';
    switch (baseKind) {
      case 'Struct': case 'Union': baseTypeId = 'struct-base'; break;
      case 'List': baseTypeId = 'list-base'; break;
      case 'Dict': baseTypeId = 'dict'; break;
      case 'Basic':
        baseTypeId = this.newType.subtypeId || 'string';
        break;
    }

    const baseType = this.bbTypeService.getTypes().find(t => t.id === baseTypeId);
    return baseType ? JSON.parse(JSON.stringify(baseType.editors)) : [{ id: 'default', name: 'Default', type: 'System', baseEditorId: 'string', publishedSettings: {}, overrides: [] }];
  }

  private updateAvailableTypes(types: BBType[]) {
    const combined = this.appConfig ? [...types.filter(t => !t.userDefined), ...this.appConfig.types] : types;
    this.allTypes = combined.filter(t => !t.isAnonymous);
  }

  ngOnInit() {
    // Subscribe to type updates
    this.bbTypeService.types$.subscribe(types => {
      this.updateAvailableTypes(types);
      this.coreTypes = types.filter(t => t.baseType === 'Core' && !t.userDefined);
    });

    if (this.editingType) {
      // Load existing type for editing
      this.newType = { ...this.editingType };
      this.baseTypeSelection = this.editingType.baseType;
      if (!this.newType.editors || this.newType.editors.length === 0) {
        this.newType.editors = this.getDefaultEditorsForBase(this.baseTypeSelection);
      }
    } else {
      this.onBaseTypeChange(); // Initialize defaults for new type
    }
  }

  onBaseTypeChange() {
    this.newType.baseType = this.baseTypeSelection;
    // Reset specific fields
    if (this.baseTypeSelection === 'Basic') {
      this.newType.values = [];
      this.newType.fields = undefined;
      // Default to String as base?
      if (this.coreTypes.length > 0) this.newType.subtypeId = this.coreTypes[0].id;
    } else if (this.baseTypeSelection === 'List' || this.baseTypeSelection === 'Dict') {
      this.newType.values = undefined;
      this.newType.fields = undefined;
      if (!this.newType.subtypeId && this.allTypes.length > 0) {
        this.newType.subtypeId = this.allTypes[0].id;
      }
    } else {
      // Struct/Union
      this.newType.values = undefined;
      this.newType.subtypeId = undefined;
      this.newType.fields = [];
    }

    // Refresh default editors for this kind
    this.newType.editors = this.getDefaultEditorsForBase(this.baseTypeSelection);
  }

  addValue() {
    if (!this.newType.values) this.newType.values = [];
    const nextId = this.newType.values.length; // Start at 0
    this.newType.values.push({ id: nextId, text: '' });
  }

  removeValue(index: number) {
    this.newType.values?.splice(index, 1);
  }

  addField() {
    if (!this.newType.fields) this.newType.fields = [];
    this.newType.fields.push({ name: '', typeId: this.allTypes[0]?.id || '' });
  }

  removeField(index: number) {
    this.newType.fields?.splice(index, 1);
  }

  onFieldTypeChange(event: any, field: BBField) {
    if (event.target.value === '__new_anon__') {
      this.pendingField = field;
      this.pendingListSubtype = false;
      this.showAnonBuilder = true;
      // Reset the select so it doesn't stay on __new_anon__ if cancelled?
      // Actually better to just leave it and handle it on save or cancel.
    }
  }

  onListSubtypeChange(event: any) {
    if (event.target.value === '__new_anon__') {
      this.pendingField = null;
      this.pendingListSubtype = true;
      this.showAnonBuilder = true;
    }
  }

  onAnonTypeCreated(anonType: BBType) {
    // 1. Mark as anonymous
    anonType.isAnonymous = true;
    anonType.parentId = this.editingType?.id || 'new'; // Link to current type

    // 2. Register in service
    const anonId = this.bbTypeService.getNextAnonymousId();
    anonType.id = anonId;
    if (this.appConfig) {
      this.appConfig.types.push(anonType);
    } else {
      this.bbTypeService.addType(anonType);
    }

    // 3. Update the pending field or list subtype
    if (this.pendingListSubtype) {
      this.newType.subtypeId = anonId;
    } else if (this.pendingField) {
      this.pendingField.typeId = anonId;
    }

    // 4. Cleanup
    this.showAnonBuilder = false;
    this.pendingField = null;
    this.pendingListSubtype = false;

    // Subscription will handle updating allTypes
  }

  addEditor() {
    const baseEditor = this.newType.editors && this.newType.editors.length > 0
      ? this.newType.editors[0]
      : { id: 'default', name: 'Default', type: 'System', publishedSettings: {}, overrides: [] };

    const newEditor: BBEditor = {
      id: 'custom-' + Date.now(),
      name: 'New Custom Editor',
      type: 'Custom',
      baseEditorId: baseEditor.id,
      publishedSettings: { ...baseEditor.publishedSettings },
      overrides: JSON.parse(JSON.stringify(baseEditor.overrides))
    };

    if (!this.newType.editors) this.newType.editors = [];
    this.newType.editors.push(newEditor);
  }

  customizeEditor(editor: BBEditor) {
    this.currentEditingEditor = editor;
    this.showEditorCustomizer = true;
  }

  onEditorCustomized(updatedEditor: BBEditor) {
    if (this.newType.editors) {
      const index = this.newType.editors.findIndex(e => e.id === updatedEditor.id);
      if (index >= 0) {
        this.newType.editors[index] = updatedEditor;
      }
    }
    this.showEditorCustomizer = false;
  }

  deleteEditor(editorId: string) {
    if (this.newType.editors) {
      this.newType.editors = this.newType.editors.filter(e => e.id !== editorId);
    }
  }

  testEditor(editor: BBEditor) {
    alert('Testing editor: ' + editor.name);
  }

  isAnonymousType(typeId: string): boolean {
    const types = this.appConfig ? [...this.bbTypeService.getTypes().filter(t => !t.userDefined), ...this.appConfig.types] : this.bbTypeService.getTypes();
    const type = types.find(t => t.id === typeId);
    return !!type?.isAnonymous;
  }

  getAnonymousTypeName(typeId: string): string {
    const types = this.appConfig ? [...this.bbTypeService.getTypes().filter(t => !t.userDefined), ...this.appConfig.types] : this.bbTypeService.getTypes();
    const type = types.find(t => t.id === typeId);
    return type ? this.bbTypeService.getTypeDisplayName(type) : 'Anonymous Type';
  }

  save() {
    if (!this.newType.name && !this.isAnonymousMode) {
      alert('Please enter a name');
      return;
    }

    // Finalize type structure
    const finalType: BBType = {
      ...this.newType as BBType,
      id: this.editingType ? this.editingType.id : (this.newType.name ? this.newType.name.toLowerCase().replace(/\s+/g, '-') : 'anon-' + Date.now()),
      editors: this.newType.editors && this.newType.editors.length > 0 ? this.newType.editors : this.getDefaultEditorsForBase(this.baseTypeSelection)
    };

    if (this.isAnonymousMode) {
      finalType.isAnonymous = true;
      finalType.name = this.bbTypeService.getTypeDisplayName(finalType);
    } else {
      finalType.name = this.newType.name!;
    }

    this.create.emit(finalType);
  }
}
