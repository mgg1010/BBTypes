import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges, Type, ViewContainerRef, ViewChild, ComponentRef, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BBTypeService } from '../services/bb-type.service';
import { BBType, BBEditor } from '../models/bb-types';
import { AppConfig } from '../models/app-models';
import { SettingsService } from '../services/settings.service';
import { EditorRegistryService } from '../services/editor-registry.service';
import { StringEditorComponent } from './string-editor.component';
import { NumberEditorComponent } from './number-editor.component';
import { BooleanEditorComponent } from './boolean-editor.component';
import { FileEditorComponent } from './file-editor.component';
import { EnumEditorComponent } from './enum-editor.component';
import { DateEditorComponent } from './date-editor.component';
import { IEditorComponent, EditorMode, EditorSize } from './editor.interface';
import { ExpressionEditorComponent } from './expression-editor.component';

@Component({
    selector: 'app-dynamic-field',
    standalone: true,
    imports: [CommonModule, ExpressionEditorComponent],
    template: `
    <div class="dynamic-field-wrapper"
         [class.dragging]="isDragging"
         (dragover)="onDragOver($event)"
         (dragleave)="onDragLeave($event)"
         (drop)="onDrop($event)">
        <ng-template #container></ng-template>
        @if (mode === 'expression') {
            <app-expression-editor
                [value]="value ? value.toString() : ''"
                (valueChange)="onExpressionChange($event)"
                [size]="size"
                [pendingVariable]="pendingVariable"
                (exitExpressionMode)="exitExpressionMode()">
            </app-expression-editor>
        }
        @if (error) {
            <div class="error">{{ error }}</div>
        }
    </div>
  `,
    styles: [`
    .error { color: red; font-size: 11px; }
    :host { display: block; width: 100%; }
    .dynamic-field-wrapper {
        width: 100%;
        min-height: 30px;
        border: 1px solid transparent;
        border-radius: 4px;
    }
    .dynamic-field-wrapper.dragging {
        border: 2px dashed #2196F3;
        background: rgba(33, 150, 243, 0.05);
    }
  `]
})
export class DynamicFieldComponent implements OnChanges {
    @Input() typeId!: string;
    @Input() appConfig: AppConfig | null = null;
    @Input() value: any;
    @Input() mode: EditorMode = 'edit';
    @Input() size: EditorSize = 'medium';
    @Input() settings: Record<string, any> = {};
    @Input() runtimeOverrides: any[] = []; // BBSettingOverride[]
    @Input() editorId?: string;
    @Input() fieldName: string = '*';
    @Output() valueChange = new EventEmitter<any>();
    @Output() modeChange = new EventEmitter<EditorMode>();

    @ViewChild('container', { read: ViewContainerRef, static: true }) container!: ViewContainerRef;

    componentRef?: ComponentRef<any>;
    error?: string;
    isDragging = false;
    pendingVariable: any = null;
    previousValue: any = null;

    constructor(
        private bbTypeService: BBTypeService,
        private settingsService: SettingsService,
        private editorRegistry: EditorRegistryService
    ) { }

    ngOnChanges(changes: SimpleChanges) {
        // Skip loading component if we're in expression mode
        if (this.mode === 'expression') {
            if (this.componentRef) {
                this.componentRef.destroy();
                this.componentRef = undefined;
            }
            return;
        }

        if (changes['typeId'] || changes['editorId'] || changes['settings'] || changes['mode'] || changes['size']) {
            this.loadComponent();
        } else if (this.componentRef) {
            // Propagate changes to instance
            if (changes['value']) this.componentRef.instance.value = this.value;
            if (changes['appConfig']) this.componentRef.instance.appConfig = this.appConfig;
        }
    }

    async loadComponent() {
        this.container.clear();
        this.error = undefined;

        if (!this.typeId) return;

        const types = this.appConfig
            ? [...this.bbTypeService.getTypes().filter(t => !t.userDefined), ...this.appConfig.types]
            : this.bbTypeService.getTypes();

        const currentType = types.find(t => t.id === this.typeId);
        if (!currentType) {
            this.error = `Type not found: ${this.typeId}`;
            return;
        }

        // 1. Resolve which editor to use
        let activeEditor: BBEditor | undefined;
        const requestedEditorId = this.editorId || this.settings[`${currentType.id}.Editor`];

        if (requestedEditorId) {
            activeEditor = (currentType.editors || []).find(e => e.id === requestedEditorId);
        }

        if (!activeEditor) {
            activeEditor = (currentType.editors || []).find(e => e.id === 'default') || (currentType.editors || [])[0];
        }

        // 1b. Fallback to a virtual editor if still no editor found (prevents crash)
        if (!activeEditor) {
            activeEditor = {
                id: 'virtual-default',
                name: 'Default',
                type: 'System',
                baseEditorId: this.getFallbackEditorId(currentType),
                publishedSettings: {},
                settingDefinitions: [],
                overrides: []
            };
        }

        // 2. Resolve settings for this level
        let localSettings = this.settings;
        localSettings = this.settingsService.mergeSettings(this.settings, activeEditor.overrides, this.fieldName);

        // 2b. Apply runtime overrides (for testing)
        if (this.runtimeOverrides?.length) {
            localSettings = this.settingsService.mergeSettings(localSettings, this.runtimeOverrides, this.fieldName);
        }

        // 3. Update dynamic field's own state from settings (e.g. override mode)
        const resolvedMode = this.settingsService.resolveSetting('UI.EditMode', localSettings, this.value) || this.mode;
        const resolvedSize = this.settingsService.resolveSetting('UI.Size', localSettings, this.value) || this.size;

        // 4. Resolve Component via Metadata (baseEditorId) or Fallback
        const editorIdToUse = activeEditor.baseEditorId || this.getFallbackEditorId(currentType);
        const componentType = await this.getComponentByEditorId(editorIdToUse);

        if (componentType) {
            this.createComponentInstance(componentType, currentType, localSettings, resolvedMode, resolvedSize, activeEditor.id, activeEditor.baseEditorId);
        } else {
            this.error = `Could not resolve component for editor ${editorIdToUse} (Type: ${currentType.baseType})`;
        }
    }

    private getFallbackEditorId(type: BBType): string {
        if (type.baseType === 'Struct' || type.baseType === 'Union') return 'struct';
        if (type.baseType === 'List') return 'list';
        if (type.baseType === 'Basic') return 'enum';
        if (type.baseType === 'Core') {
            const root = this.resolveRootType(type); // Keep resolveRootType for now, it's used here
            return root?.toLowerCase() || 'string';
        }
        return 'string';
    }

    private async getComponentByEditorId(editorId: string): Promise<Type<any> | null> {
        return this.editorRegistry.getComponent(editorId);
    }

    private createComponentInstance(componentClass: Type<any>, type: BBType, settings: Record<string, any>, mode: EditorMode, size: EditorSize, editorId?: string, baseEditorId?: string) {
        this.componentRef = this.container.createComponent(componentClass);
        const instance = this.componentRef.instance;

        instance.subtypeId = type.subtypeId;
        if (type.fields) instance.fields = [...type.fields];
        if (type.values) instance.values = [...type.values];
        (instance as any).bbType = type;

        instance.appConfig = this.appConfig;
        instance.value = this.value;
        instance.mode = mode;
        instance.size = size;
        instance.settings = settings;
        instance.runtimeOverrides = this.runtimeOverrides;
        instance.editorId = editorId;
        instance.baseEditorId = baseEditorId;
        if (instance.valueChange) {
            instance.valueChange.subscribe((val: any) => {
                this.value = val;
                this.valueChange.emit(val);
            });
        }
        if (instance.modeChange) {
            instance.modeChange.subscribe((m: EditorMode) => {
                this.mode = m;
                this.modeChange.emit(m);
            });
        }
    }

    onExpressionChange(newValue: string) {
        this.value = newValue;
        this.valueChange.emit(newValue);
    }

    onDragOver(event: DragEvent) {
        if (this.mode === 'expression') return;
        event.preventDefault();
        event.stopPropagation();
        this.isDragging = true;
    }

    onDragLeave(event: DragEvent) {
        this.isDragging = false;
    }

    onDrop(event: DragEvent) {
        if (this.mode === 'expression') return;
        event.preventDefault();
        event.stopPropagation();
        this.isDragging = false;

        const data = event.dataTransfer?.getData('application/json');
        if (data) {
            try {
                const dropped = JSON.parse(data);
                if (dropped.type === 'variable') {
                    this.pendingVariable = dropped;
                    this.mode = 'expression';
                    this.modeChange.emit('expression');
                }
            } catch (e) {
                console.error('Error parsing dropped data', e);
            }
        }
    }

    exitExpressionMode() {
        this.mode = 'edit';
        this.modeChange.emit('edit');
        this.value = this.previousValue;
        this.valueChange.emit(this.value);
        this.pendingVariable = null;
    }

    resolveRootType(type: BBType): string | undefined {
        if (type.baseType === 'Core') return type.name;
        if (type.baseType === 'Basic' && type.subtypeId) {
            const types = this.appConfig
                ? [...this.bbTypeService.getTypes().filter(t => !t.userDefined), ...this.appConfig.types]
                : this.bbTypeService.getTypes();
            const parent = types.find(t => t.id === type.subtypeId);
            if (parent) return this.resolveRootType(parent);
        }
        return undefined;
    }
}
