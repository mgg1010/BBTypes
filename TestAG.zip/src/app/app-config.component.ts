import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AppService } from './services/app.service';
import { AppConfig, AppScreen } from './models/app-models';
import { FormsModule } from '@angular/forms';
import { BBTypeListComponent } from './bb-types/bb-type-list.component';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-config',
    standalone: true,
    imports: [CommonModule, FormsModule, RouterModule, BBTypeListComponent],
    template: `
    <div class="config-container">
      <header>
        <button class="back-link" routerLink="/">⬅ Back to Dashboard</button>
        <h1>{{ isNew ? 'New App' : 'Config: ' + app?.name }}</h1>
        <button class="save-status-btn" disabled>Syncing Automatically...</button>
      </header>

      @if (app) {
        <nav class="tabs">
          <button [class.active]="activeTab === 'settings'" (click)="activeTab = 'settings'">Core Settings</button>
          <button [class.active]="activeTab === 'types'" (click)="activeTab = 'types'">Types List</button>
          <button [class.active]="activeTab === 'screens'" (click)="activeTab = 'screens'">Screens List</button>
        </nav>

        <div class="tab-content">
          <!-- Core Settings -->
          @if (activeTab === 'settings') {
            <div class="settings-form">
              <div class="field">
                <label>App Name</label>
                <input [(ngModel)]="app.name" (ngModelChange)="onNameChange()" placeholder="e.g. Inventory Manager">
              </div>
              <div class="field">
                <label>App Slug (URL identifier)</label>
                <input [(ngModel)]="app.slug" placeholder="e.g. inventory">
                <small>Used at {{ currentOrigin }}/{{ app.slug }}</small>
              </div>
            </div>
          }

          <!-- Types List -->
          @if (activeTab === 'types') {
            <div class="types-section">
                <app-bb-type-list [appConfig]="app" (appConfigChange)="onAppChanged()"></app-bb-type-list>
            </div>
          }

          <!-- Screens List -->
          @if (activeTab === 'screens') {
            <div class="screens-section">
              <div class="toolbar">
                <h3>App Screens</h3>
                <button class="add-btn" (click)="addScreen()">+ Add Screen</button>
              </div>
              
              <div class="screen-list">
                @for (screen of app.screens; track screen.id; let i = $index) {
                  <div class="screen-card">
                    <div class="screen-main">
                      <input [(ngModel)]="screen.name" placeholder="Screen Name" (ngModelChange)="onAppChanged()">
                      <select [(ngModel)]="screen.type" (ngModelChange)="onAppChanged()">
                        <option value="list">List Editor</option>
                      </select>
                      <select [(ngModel)]="screen.typeId" (ngModelChange)="onAppChanged()">
                        <option value="">-- Select Type --</option>
                        @for (type of app.types; track type.id) {
                           <option [value]="type.id">{{ type.name }}</option>
                        }
                      </select>
                    </div>
                    <button class="remove-btn" (click)="removeScreen(i)">🗑️</button>
                  </div>
                }
                @if (app.screens.length === 0) {
                  <p class="empty">No screens defined yet.</p>
                }
              </div>
            </div>
          }
        </div>
      } @else {
        <div class="loading">Loading App...</div>
      }
    </div>
  `,
    styles: [`
    .config-container { padding: 30px; max-width: 1200px; margin: 0 auto; }
    header { display: flex; align-items: center; gap: 20px; margin-bottom: 30px; }
    h1 { margin: 0; flex: 1; }
    .back-link { background: none; border: none; color: #2196F3; cursor: pointer; padding: 0; font-weight: bold; }
    .save-status-btn { font-size: 0.8rem; background: #eee; border: 1px solid #ddd; padding: 4px 10px; border-radius: 4px; color: #888; }

    .tabs { display: flex; border-bottom: 2px solid #eee; margin-bottom: 30px; }
    .tabs button { 
      padding: 12px 24px; background: none; border: none; cursor: pointer; 
      font-weight: 600; font-size: 1rem; color: #666; position: relative;
    }
    .tabs button.active { color: #2196F3; }
    .tabs button.active::after { content: ''; position: absolute; bottom: -2px; left: 0; right: 0; height: 2px; background: #2196F3; }

    .settings-form { max-width: 500px; }
    .field { margin-bottom: 20px; }
    .field label { display: block; margin-bottom: 5px; font-weight: 600; color: #444; }
    .field input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; border-box: border-box; }
    .field small { color: #888; display: block; margin-top: 4px; }

    .screens-section .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .screen-list { display: grid; gap: 15px; }
    .screen-card { 
      display: flex; gap: 10px; align-items: center; background: white; padding: 15px; 
      border-radius: 8px; border: 1px solid #eee; box-shadow: 0 2px 4px rgba(0,0,0,0.03);
    }
    .screen-main { flex: 1; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
    .screen-main input, .screen-main select { padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
    .remove-btn { background: none; border: none; cursor: pointer; font-size: 1.2rem; filter: grayscale(1); }
    .remove-btn:hover { filter: none; }
    .empty { color: #999; text-align: center; font-style: italic; }
    
    .add-btn { background: #4CAF50; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-weight: 600; }
  `]
})
export class AppConfigComponent implements OnInit, OnDestroy {
    app: AppConfig | null = null;
    activeTab: 'settings' | 'types' | 'screens' = 'settings';
    isNew = false;
    currentOrigin = window.location.origin;

    private routeSub: Subscription | null = null;

    constructor(
        private route: ActivatedRoute,
        private appService: AppService,
        private router: Router
    ) { }

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            const slug = params['slug'];
            const found = this.appService.getAppBySlug(slug);
            if (found) {
                this.app = { ...found }; // Clone for editing? Actually we want auto-sync in this case
                this.isNew = false;
            } else {
                // Should handle 404
                this.router.navigate(['/']);
            }
        });
    }

    ngOnDestroy() {
        this.routeSub?.unsubscribe();
    }

    onNameChange() {
        if (this.app && !this.app.slug) {
            this.app.slug = this.app.name.toLowerCase().replace(/\\s+/g, '-');
        }
        this.onAppChanged();
    }

    onAppChanged() {
        if (this.app) {
            this.appService.updateApp(this.app.slug, this.app);
        }
    }

    addScreen() {
        if (!this.app) return;
        const newScreen: AppScreen = {
            id: 'screen-' + Date.now(),
            name: 'New Screen ' + (this.app.screens.length + 1),
            type: 'list',
            typeId: ''
        };
        this.app.screens.push(newScreen);
        this.onAppChanged();
    }

    removeScreen(index: number) {
        if (!this.app) return;
        this.app.screens.splice(index, 1);
        this.onAppChanged();
    }
}
