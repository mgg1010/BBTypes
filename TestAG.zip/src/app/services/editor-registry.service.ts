import { Injectable, Type } from '@angular/core';
import { StringEditorComponent } from '../shared/string-editor.component';
import { NumberEditorComponent } from '../shared/number-editor.component';
import { BooleanEditorComponent } from '../shared/boolean-editor.component';
import { FileEditorComponent } from '../shared/file-editor.component';
import { EnumEditorComponent } from '../shared/enum-editor.component';
import { DateEditorComponent } from '../shared/date-editor.component';

type EditorEntry =
    | { kind: 'eager'; component: Type<any> }
    | { kind: 'lazy'; loader: () => Promise<any> };

@Injectable({
    providedIn: 'root'
})
export class EditorRegistryService {
    private registry = new Map<string, EditorEntry>();

    constructor() {
        this.registerDefaultEditors();
    }

    private registerDefaultEditors() {
        // Eagerly loaded components
        this.registerEditor('string', StringEditorComponent);
        this.registerEditor('number', NumberEditorComponent);
        this.registerEditor('checkbox', BooleanEditorComponent);
        this.registerEditor('boolean', BooleanEditorComponent);
        this.registerEditor('file', FileEditorComponent);
        this.registerEditor('date', DateEditorComponent);
        this.registerEditor('enum', EnumEditorComponent);
        this.registerEditor('radio', EnumEditorComponent);

        // Lazy loaded components
        this.registerLazyEditor('struct', () => import('../shared/struct-editor.component').then(m => m.StructEditorComponent));
        this.registerLazyEditor('list', () => import('../shared/list-editor.component').then(m => m.ListEditorComponent));
        this.registerLazyEditor('dict', () => import('../shared/dict-editor.component').then(m => m.DictEditorComponent));
    }

    registerEditor(id: string, component: Type<any>) {
        this.registry.set(id, { kind: 'eager', component });
    }

    registerLazyEditor(id: string, loader: () => Promise<any>) {
        this.registry.set(id, { kind: 'lazy', loader });
    }

    async getComponent(id: string): Promise<Type<any> | null> {
        const entry = this.registry.get(id);
        if (!entry) return null;

        if (entry.kind === 'eager') {
            return entry.component;
        } else {
            try {
                return await entry.loader();
            } catch (e) {
                console.error(`Failed to load editor for ${id}`, e);
                return null;
            }
        }
    }
}
