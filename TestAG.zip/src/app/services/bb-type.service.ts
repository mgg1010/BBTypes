import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { BBType, BBSettingDefinition } from '../models/bb-types';
import { INITIAL_CORE_TYPES } from '../bb-types/core-types';

@Injectable({
    providedIn: 'root'
})
export class BBTypeService {
    private typesSubject = new BehaviorSubject<BBType[]>([]);
    types$ = this.typesSubject.asObservable();

    constructor() {
        this.initializeCoreTypes();
        this.loadUserDefinedTypes();
    }

    private initializeCoreTypes() {
        this.typesSubject.next([...INITIAL_CORE_TYPES]);
    }

    getTypes(): BBType[] {
        return this.typesSubject.value;
    }

    addType(type: BBType) {
        const types = this.getTypes();
        this.typesSubject.next([...types, type]);
        this.saveTypes();
    }

    updateType(updatedType: BBType) {
        const types = this.getTypes();
        const index = types.findIndex(t => t.id === updatedType.id);
        if (index >= 0) {
            types[index] = updatedType;
            this.typesSubject.next([...types]);
            this.saveTypes();
        }
    }

    saveTypes() {
        const userTypes = this.getTypes().filter(t => t.userDefined);
        localStorage.setItem('bb-types-custom', JSON.stringify(userTypes));
    }

    importTypes(newTypes: BBType[]) {
        const currentCore = this.getTypes().filter(t => !t.userDefined);
        const currentCustom = this.getTypes().filter(t => t.userDefined);

        // For simplicity, let's say imported types overwrite existing custom types with same ID
        const mergedCustom = [...currentCustom];
        for (const t of newTypes) {
            const idx = mergedCustom.findIndex(c => c.id === t.id);
            if (idx >= 0) mergedCustom[idx] = t;
            else mergedCustom.push(t);
        }

        this.typesSubject.next([...currentCore, ...mergedCustom]);
        this.saveTypes();
    }

    loadUserDefinedTypes() {
        const saved = localStorage.getItem('bb-types-custom');
        if (saved) {
            try {
                const customTypes = JSON.parse(saved);
                const currentTypes = this.getTypes();
                const coreIds = new Set(currentTypes.filter(t => !t.userDefined).map(t => t.id));

                // Only load types that are userDefined AND don't collide with core IDs
                const filteredCustom = customTypes.filter((t: any) => t.userDefined && !coreIds.has(t.id));

                this.typesSubject.next([...currentTypes.filter(t => !t.userDefined), ...filteredCustom]);
            } catch (err) {
                console.error('Failed to load custom types from localStorage', err);
            }
        }
    }

    getNextAnonymousId(): string {
        const anonTypes = this.getTypes().filter(t => t.id.startsWith('anon-'));
        let maxId = 0;
        anonTypes.forEach(t => {
            const num = parseInt(t.id.replace('anon-', ''));
            if (!isNaN(num) && maxId < num) maxId = num;
        });
        return `anon-${maxId + 1}`;
    }

    getTypeDisplayName(type: BBType): string {
        if (type.baseType === 'List') {
            const subtype = this.getTypes().find(t => t.id === type.subtypeId);
            return `List of ${subtype ? (subtype.isAnonymous ? this.getTypeDisplayName(subtype) : subtype.name) : '?'}`;
        }
        if (type.baseType === 'Dict') {
            const subtype = this.getTypes().find(t => t.id === type.subtypeId);
            return `Dict of ${subtype ? (subtype.isAnonymous ? this.getTypeDisplayName(subtype) : subtype.name) : '?'}`;
        }
        if (type.baseType === 'Basic') {
            const subtype = this.getTypes().find(t => t.id === type.subtypeId);
            return `Custom ${subtype ? subtype.name : 'Type'}`;
        }
        return `Custom ${type.baseType}`;
    }

    clearAllTypes() {
        localStorage.removeItem('bb-types-custom');
        this.initializeCoreTypes();
    }

    // Centralized discovery of all available settings for a type (used by Editor Customization & Test Sidebar)
    getAvailableSettings(type: BBType): BBSettingDefinition[] {
        const settings: BBSettingDefinition[] = [];
        const seen = new Set<string>();

        const addFromType = (typeId: string) => {
            const types = this.getTypes();
            const t = types.find(x => x.id === typeId);
            if (!t) return;

            // Add settings from all editors of this type
            t.editors.forEach(ed => {
                (ed.settingDefinitions || []).forEach(def => {
                    if (!seen.has(def.id)) {
                        settings.push(def);
                        seen.add(def.id);
                    }
                });
            });
        };

        // 1. If it's a struct/union, check fields
        if (type.baseType === 'Struct' || type.baseType === 'Union') {
            (type.fields || []).forEach(f => addFromType(f.typeId));
        }
        // 2. If it's a list/dict, check subtype
        else if (type.baseType === 'List' || type.baseType === 'Dict') {
            if (type.subtypeId) addFromType(type.subtypeId);
        }

        // Also add UI defaults
        if (!seen.has('UI.Size')) { settings.push({ id: 'UI.Size', name: 'Size', typeId: 'string' }); seen.add('UI.Size'); }

        return settings;
    }

    isTypeReferenced(typeId: string): boolean {
        return this.getTypesReferencing(typeId).length > 0;
    }

    getTypesReferencing(typeId: string): BBType[] {
        const referencingTypes: BBType[] = [];
        const allTypes = this.getTypes();

        for (const type of allTypes) {
            if (type.id === typeId) continue; // Don't check self-references

            // Check subtype usage (List, Dict, Basic)
            if (type.subtypeId === typeId) {
                referencingTypes.push(type);
                continue;
            }

            // Check field usage (Struct, Union)
            if (type.fields) {
                const fieldUsage = type.fields.find(f => f.typeId === typeId);
                if (fieldUsage) {
                    referencingTypes.push(type);
                    continue;
                }
            }
        }
        return referencingTypes;
    }

    deleteType(typeId: string) {
        const types = this.getTypes().filter(t => t.id !== typeId);
        this.typesSubject.next(types);
        this.saveTypes();
    }
}
