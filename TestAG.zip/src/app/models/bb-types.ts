export type BBTypeBase = 'Core' | 'Basic' | 'List' | 'Struct' | 'Union' | 'Dict';

export interface BBValue {
    id: string | number;
    text: string;
}

export interface BBSettingDefinition {
    id: string;
    name: string;
    typeId: string; // reference to BBType
    description?: string;
}

export interface BBField {
    name: string;
    typeId: string; // Reference to another BBType by name or ID
}

export interface BBSettingOverride {
    fieldName: string; // "*" for all or specific name
    settingId: string; // e.g. "UI.EditMode"
    value: any;
    isExpression?: boolean;
}

export interface BBEditor {
    id: string;
    name: string;
    type: 'System' | 'Custom';
    baseEditorId?: string;
    publishedSettings: Record<string, 'published' | 'hidden'>; // Map of ID -> status
    settingDefinitions?: BBSettingDefinition[]; // Definitions for settings this editor publishes
    overrides: BBSettingOverride[];
}

export interface BBType {
    id: string; // Unique Identifier (often Name for core types)
    name: string;
    baseType: BBTypeBase;
    userDefined: boolean;
    isAnonymous?: boolean;
    parentId?: string;

    // For Basic types (Enums)
    values?: BBValue[];

    // For List types
    subtypeId?: string;

    // For Struct/Union types
    fields?: BBField[];

    // Intrinsic Settings (Type-level constraints)
    // String
    validationRules?: any[]; // List of String.ValidationRule objects
    maxLen?: number;
    maxLenMsg?: string;
    minLen?: number;
    minLenMsg?: string;

    // Number
    allowNegative?: boolean;
    allowNegativeMsg?: string;
    allowDecimals?: boolean;
    allowDecimalsMsg?: string;
    allowScientific?: boolean;
    allowScientificMsg?: string;

    editors: BBEditor[];
}
